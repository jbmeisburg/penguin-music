﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin.Security;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CapstoneBlog
{
    public partial class Register : System.Web.UI.Page
    {
        protected void CreateUser_Click(object sender, EventArgs e)
        {

            // Default UserStore constructor uses the default connection string named: DefaultConnection
            var userStore = new UserStore<IdentityUser>();
            var manager = new UserManager<IdentityUser>(userStore);

            var user = new IdentityUser() { UserName = UserName.Text };
            IdentityResult result = manager.Create(user, Password.Text);

            try
            {
                if (result.Succeeded)
                {
                    var authenticationManager = HttpContext.Current.GetOwinContext().Authentication;
                    var userIdentity = manager.CreateIdentity(user, DefaultAuthenticationTypes.ApplicationCookie);
                    var roleResult = manager.AddToRole(user.Id, RoleName.Text);
                    authenticationManager.SignIn(new AuthenticationProperties() { }, userIdentity);

                    /***GARY ADDED THIS SORRY NOT SORRY***/
                    using (SqlConnection conn = new SqlConnection())
                    {
                        conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = conn;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "AddNewUser";
                        cmd.Parameters.AddWithValue("@UserName", user.UserName);
                        conn.Open();
                        cmd.ExecuteNonQuery();
                    };
                    //</soDirty>

                    Response.Redirect("http://localhost:8080/home/index");
                }
                else
                {
                    StatusMessage.Text = result.Errors.FirstOrDefault();
                }
            }
            catch (Exception)
            {

                Response.Redirect("http://localhost:8080/register.aspx");
            }
        }
    }
}