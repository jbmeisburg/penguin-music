﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CapstoneBlog.BLL;

using CapstoneBlog.Models;
using System.IO;
using CapstoneBlog.Data;

namespace CapstoneBlog.Controllers
{
    public class HomeController : Controller
    {
        //public HomeController(IPostRepo postRepo, IPageRepo pageRepo)
        //{
        //    _postManager = new PostManager(postRepo);
        //    _pageManager = new PageManager(pageRepo);
        //}

        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";
            PageManager tmpPM = new PageManager(new MockPageRepo());
            return View(tmpPM.GetAllPages());
        }
        
        [Authorize]
        public ActionResult NewPost()
        {
            return View();
        }

        [Authorize]
        public ActionResult EditPost(int id)
        {
            return View();
        }
        
        public ActionResult StaticPage(Page page)
        {
            return View(page);
        }

        [Authorize]
        public ActionResult NewPage()
        {
            return View();
        }

        [AcceptVerbs("Post")]
        public string UploadImage(HttpPostedFileBase image)
        {
            string relativeloc = "/Uploads/";
            string filename = image.FileName;

            image.SaveAs(Path.Combine(Server.MapPath("~/Uploads/"), filename));
            return "<script>top.$('.mce-btn.mce-open').parent().find('.mce-textbox').val('" + relativeloc + filename + "').closest('.mce-window').find('.mce-primary').click();</script>";
        }


        [Authorize]
        public ActionResult EditPage(Page page)
        {
            return View(page);
        }
    }
}
