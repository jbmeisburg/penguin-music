﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CapstoneBlog.Models;
using CapstoneBlog.BLL;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Web.Http.Results;
using System.Web;
using System.IO;
using System.Configuration;

namespace CapstoneBlog.Controllers
{
    public class DataController : ApiController
    {
        static PostManager _postManager;
        static PageManager _pageManager;

        public DataController(IPostRepo postRepo, IPageRepo pageRepo)
        {
            if (_postManager == null) {
                _postManager = new PostManager(postRepo);
                if (ConfigurationManager.AppSettings["mode"].ToString() == "mock")
                {
                    _postManager.LoadDemo();
                }
            }
            if (_pageManager == null)
                _pageManager = new PageManager(pageRepo);

            //TODO: Move to Global.asax
            var settings = GlobalConfiguration
                            .Configuration
                            .Formatters
                            .JsonFormatter
                            .SerializerSettings;
            settings.Formatting = Formatting.Indented;
            settings.ContractResolver = new CamelCasePropertyNamesContractResolver();
        }

        [Route("LoadDemo")]
        [AcceptVerbs("Post")]
        public IHttpActionResult LoadDemo()
        {
            _postManager.LoadDemo();
            _pageManager.LoadDemo();
            return Ok();
        }

        /*********BLOG POST METHODS**********/

        [Route("Post/Add")]
        [AcceptVerbs("Post")]
        public IHttpActionResult AddPost(Post post)
        {
            if (post != null && ModelState.IsValid)
            {
                int id = _postManager.AddPost(post);
                return Ok(id);
            }
            else
            {
                string message = "Add post invalid!";
                foreach (var state in ModelState)
                {
                    foreach (var error in state.Value.Errors)
                    {
                        message += " " + error.ErrorMessage;
                    }
                }
                return BadRequest(message);
            }
        }

        [Route("Post/Delete/{id}")]
        [AcceptVerbs("Post")]
        public IHttpActionResult DeletePost(int id)
        {
            _postManager.DeletePost(id);
            return Ok();
        }

        [Route("Post/Update")]
        [AcceptVerbs("Post")]
        public IHttpActionResult UpdatePost(Post post)
        {
            if (post != null && ModelState.IsValid)
            {
                _postManager.UpdatePost(post);
                return Ok();
            }
            else
            {
                string message = "Update post invalid!";
                foreach (var state in ModelState)
                {
                    foreach (var error in state.Value.Errors)
                    {
                        message += " " + error.ErrorMessage;
                    }
                }
                return BadRequest(message); ;
            }
        }

        [Route("Post/{id}")]
        [AcceptVerbs("Get")]
        public IHttpActionResult GetPost(int id)
        {
            Post post = _postManager.GetPost(id);
            if (post == null)
            {
                return NotFound();
            }
            else
            {
                return Ok(post);
            }
        }

        [Route("Posts/")] //Default: approved only & current only
        [AcceptVerbs("Get")]
        public IHttpActionResult GetValidPosts()
        {
            return Ok(_postManager.GetAllPosts(approvedOnly: true, onDate: DateTime.Now));
        }

        [Route("Posts/All")] //Can request all
        [AcceptVerbs("Get")]
        public IHttpActionResult GetAllPosts()
        {
            return Ok(_postManager.GetAllPosts(approvedOnly: false, onDate: null));
        }

        [Route("Posts/Unapproved")] //Can request only unapproved
        [AcceptVerbs("Get")]
        public IHttpActionResult GetUnapprovedPosts()
        {
            return Ok(_postManager.SearchPosts("approved", "F", false, null));
        }


        /*********SEARCH BLOG POSTS*********/

        [Route("Posts/{field}/{searchTerm}")] //Default: approved only
        [AcceptVerbs("Get")]
        public IHttpActionResult SearchValidPosts(string field, string searchTerm)
        {
            return Ok(_postManager.SearchPosts(field, searchTerm, approvedOnly: true, onDate: DateTime.Now));
        }

        [Route("Posts/All/{field}/{searchTerm}")] //Can request all
        [AcceptVerbs("Get")]
        public IHttpActionResult SearchAllPosts(string field, string searchTerm)
        {
            return Ok(_postManager.SearchPosts(field, searchTerm, approvedOnly: false, onDate: null));
        }

        /*********PAGE METHODS**********/

        [Route("Page/Add")]
        [AcceptVerbs("Post")]
        public IHttpActionResult AddPage(Page page)
        {
            if (page != null && ModelState.IsValid)
            {
                int id = _pageManager.AddPage(page);
                return Ok(id);
            }
            else
            {
                string message = "Add page invalid!";
                foreach (var state in ModelState)
                {
                    foreach (var error in state.Value.Errors)
                    {
                        message += " " + error.ErrorMessage;
                    }
                }
                return BadRequest(message);
            };
        }

        [Route("Page/Delete/{id}")]
        [AcceptVerbs("Post")]
        public IHttpActionResult DeletePage(int id)
        {
            _pageManager.DeletePage(id);
            return Ok();
        }

        [Route("Page/Update")]
        [AcceptVerbs("Post")]
        public IHttpActionResult UpdatePage(Page page)
        {
            if (page != null && ModelState.IsValid)
            {
                _pageManager.UpdatePage(page);
                return Ok();
            }
            else
            {
                string message = "Update page invalid!";
                foreach (var state in ModelState)
                {
                    foreach (var error in state.Value.Errors)
                    {
                        message += " " + error.ErrorMessage;
                    }
                }
                return BadRequest(message);
            }
        }

        [Route("Pages/")]
        [AcceptVerbs("Get")]
        public IHttpActionResult GetAllPages()
        {
            return Ok(_pageManager.GetAllPages());
        }

        /*********META METHODS**********/

        [Route("Categories/")]
        [AcceptVerbs("Get")]
        public IHttpActionResult GetAllCategories()
        {
            return Ok(_postManager.GetAllCategories());
        }
    }
}

