﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CapstoneBlog.Controllers
{
    public class AdminController : Controller
    {
        //[Authorize]
        public ActionResult NewUser()
        {
            return View();
        }

        //[Authorize]
        public ActionResult EditUser()
        {
            return View();
        }

        //[Authorize]
        public ActionResult Users()
        {
            return View();
        }
    }
}