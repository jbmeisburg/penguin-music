﻿$(document).ready(function () {

    $('#error-messages').hide();
    loadAllPosts();

});

function loadAllPosts() {
    $.ajax({
        type: 'GET',
        url: 'http://localhost:8080/posts/',
        success: function (postArray) {
            $.each(postArray, function (index, post) {
                var Id = post.id;
                var Title = post.title;
                var Content = post.content;
                var Approved = post.approved;
                var PostDate = post.postDate;
                var Author = post.author.userName;
                var Category = post.category.name;
                var Tags = post.tags;

                var entry = '<div>';
                entry += '<h2>' + Title + '</h2>';
                entry += '<p style="color:gray"><small>By ' + Author + ' in ' + Category + ' on ';
                entry += moment(PostDate).format('MM/DD/YYYY') + '</small></p>';
                if (Approved === false) {
                    entry += '<p style="color:red">This post has not yet been approved</p>';
                    };
                entry += Content;
                if (Tags != null) {
                    entry += '<p style="color:gray">';
                    $.each(Tags, function (index, tag) {
                        var Name = tag.name;

                        entry += '#' + Name + ' ';
                    });
                    entry += '</p>';
                }
                entry += '</div><hr/>';

                $('#page-body').append(entry);
            });
        },
        error: function () {
            $('#error-messages').append('<li>Error contacting database. Please try again later.</li>');
            $('#error-messages').show();
        }
    });
};

$('#search-button').click(function () {
    $('#page-body').empty();
    $.ajax({
        type: 'get',
        url: 'http://localhost:8080/posts/' + $('#search-select').val() + '/' + $('#search-bar').val(),
        success: function (postArray) {
            $.each(postArray, function (index, post) {
                var Id = post.id;
                var Title = post.title;
                var Content = post.content;
                var Approved = post.approved;
                var PostDate = post.postDate;
                var Author = post.author.userName;
                var Category = post.category.name;
                var Tags = post.tags;

                var entry = '<div>';
                entry += '<h2>' + Title + '</h2>';
                entry += '<p style="color:gray"><small>By ' + Author + ' in ' + Category + ' on ';
                entry += moment(PostDate).format('MM/DD/YYYY') + '</small></p>';
                if (Approved === false) {
                    entry += '<p style="color:red">This post has not yet been approved</p>';
                };
                entry += Content;
                if (Tags != null) {
                    entry += '<p style="color:gray">';
                    $.each(Tags, function (index, tag) {
                        var Name = tag.name;

                        entry += '#' + Name + ' ';
                    });
                    entry += '</p>';
                }
                entry += '</div><hr/>';

                $('#page-body').append(entry);
            });
        },
        error: function () {
            $('#error-messages').append('<li>Error contacting database. Please try again later.</li>');
            $('#error-messages').show();
        }
    })
})