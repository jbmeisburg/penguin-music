﻿$(document).ready(function () {
    $('#delete-post').hide();
    $('#tag-field').hide();
    $('#category-select').hide();
    $('#tags').hide();
    $('#approved-field').hide();
    $('#schedule-field').hide();
    $('#expire-date').hide();
    $('#tag-button').hide();
    $('#input-fields').hide();
});

$('#save-post').click(function () {
    //var tags = $(".dist-tag");
    //var tagArray = [];
    //$.each(tags, function (i, v) {
    //    tagArray.push(v.innerText);
    //});

    //if (tagArray.length == 0) {
    //    tagArray = null;
    //}

    tinyMCE.triggerSave();

    $.ajax({
        type: 'POST',
        url: 'http://localhost:8080/page/add',
        data: JSON.stringify({
            id: 0,
            name: $('#title').val(),
            html: $('#post-body').val(),
        }),
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        'dataType': 'json',
        success: function () {
            //$('#title').val('');
            //$('#post-body').val('');
            //$('#approved-field').val('');
            //$('#schedule-field').val('');
            //$('#expire-field').val('');

            window.location.replace('http://localhost:8080');

        },
        error: function (response) {
            $('#error-messages').append(response.responseJSON.message);
        }
    })
});

$('#tag-button').click(function () {
    if ($('#tag-field').val() != '') {
        $('#tags').append($('<button>').attr({ class: 'dist-tag label label-default' }).attr({ style: 'margin:2px' }).attr({ id: 'dist-tag' }).text($('#tag-field').val()));
        $('#tag-field').val('');
    }
});

$('body').on('click', '#dist-tag', function () {
    this.remove();
});

$('#cancel-post').click(function () {
    window.location.replace('http://localhost:8080');
})
