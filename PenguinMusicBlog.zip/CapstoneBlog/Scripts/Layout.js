﻿//$(document).ready(function () {
//    //loadCategories();
//});

//function loadCategories() {
//    $.ajax({
//        type: 'GET',
//        url: 'http://localhost:8080/categories',
//        success: function (categoryArray) {
//            $.each(categoryArray, function (index, category) {
//                //var Id = category.Id;
//                var Name = category;

//                var link = '<li><a href="#" onclick="filter(\'' + Name + '\')">' + Name + '</a></li>';

//                $('#category-dropdown').append(link);
//            });
//        },
//        error: function () {
//            $('#category-dropdown').append('<li>error calling database</li>');
//        }
//    })
//};

