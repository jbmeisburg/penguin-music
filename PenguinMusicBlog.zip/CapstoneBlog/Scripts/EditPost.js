﻿$(document).ready(function () {
    var url = window.location.href;
    var postId = url.substring(url.lastIndexOf('/') + 1);
    $.ajax({
        type: 'GET',
        url: 'http://localhost:8080/post/' + postId,
        success: function (post) {
            var Id = post.id;
            var Title = post.title;
            var Content = post.content;
            var Approved = post.approved;
            var PostDate = moment(post.postDate).format('YYYY-MM-DD');
            var ExpirationDate = moment(post.expirationDate).format('YYYY-MM-DD');
            var Category = post.category;
            var Tags = post.tags;

            $('#id-field').val(Id);
            $('#title').val(Title);
            //$('#category-select').append(Category);
            tinyMCE.get('post-body').setContent(Content);
            if (Approved == true) {
                $('#approved-field').attr('checked', true);
            }
            else {
                $('#approved-field').attr('checked', false);
            }
            $('#schedule-field').val(PostDate);
            $('#expire-date').val(ExpirationDate);
            if (Tags != null) {
                $.each(Tags, function (index, tag) {
                    $('#tags').append($('<button>').attr({ class: 'dist-tag label label-default' }).attr({ style: 'margin:2px' }).attr({ id: 'dist-tag' }).text(tag.name));
                })
            }
        },
        error: function () {
            $('#error-messages').append('<li>Error contacting database. Please try again later.</li');
        }
    });

    loadCategories();
});

$('#save-post').click(function () {
    var tags = $(".dist-tag");
    var tagArray = [];
    $.each(tags, function (i, v) {
        tagArray.push({ id: 0, name: v.innerText });
    });

    if (tagArray.length == 0) {
        tagArray = null;
    }
    var expirationdate;
    if ($('#expire-date').val() == "") {
        expirationdate = null;
    }
    else {
        expirationdate = $('#expire-date').val();
    }
    tinyMCE.triggerSave();

    $.ajax({
        type: 'POST',
        url: 'http://localhost:8080/post/update',
        data: JSON.stringify({
            id: $('#id-field').val(),
            title: $('#title').val(),
            content: $('#post-body').val(),
            approved: $('#approved-field')[0].checked,
            postDate: $('#schedule-field').val(),
            expirationDate: expirationdate,
            author: {
                id: 0,
                userName: $('#author-name').val()
            },
            category: {
                id: 0,
                name: $('#categories').val()
            },
            tags: tagArray
        }),
        headers: {
            //'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        //'dataType': 'json',
        success: function () {
            $('#title').val('');
            $('#post-body').val('');
            $('#approved-field').val('');
            $('#schedule-field').val('');
            $('#expire-date').val('');

            window.location.replace('http://localhost:8080');

        },
        error: function (response) {
            $('#error-messages').append(response.responseJSON.message);
        }
    })
});

$('#tag-button').click(function () {
    if ($('#tag-field').val() != '') {
        $('#tags').append($('<button>').attr({ class: 'dist-tag label label-default' }).attr({ style: 'margin:2px' }).attr({ id: 'dist-tag' }).text($('#tag-field').val()));
        $('#tag-field').val('');
    }
});

$('body').on('click', '#dist-tag', function () {
    this.remove();
});

$('#delete-post').click(function () {
    bootbox.confirm({
        size: "small",
        title: "Delete Post",
        message: "Are you sure you want to delete this post? It will be gone forever!",
        callback: function(result){
            if (result == true) {
                $.ajax({
                    type: 'post',
                    url: 'http://localhost:8080/post/delete/' + $('#id-field').val(),
                    success: function () {
                        window.location.replace('http://localhost:8080');
                    },
                    error:function(){
                        $('#error-messages').append('<li>Error calling databse. Please try again later.</li>');
                    }
                })
            }
        }
    })
});

$('#cancel-post').click(function () {
    window.location.replace('http://localhost:8080');
});

function loadCategories() {
    $.ajax({
        type: 'GET',
        url: 'http://localhost:8080/categories',
        success: function (categoryArray) {
            $.each(categoryArray, function (index, category) {
                //var Id = category.Id;
                var Name = category;

                var link = '<option>' + Name + '</option>';

                $('#categories').append(link);
            });
        },
        error: function () {
            $('#error-messages').append('<li>error calling database</li>');
        }
    })
};