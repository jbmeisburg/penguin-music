﻿$(document).ready(function () {
    $.ajax({
        type: 'get',
        url: 'http://localhost:8080/pages',
        success: function (pageArray) {
            $.each(pageArray, function (index, page) {
                var id = page.id;
                var name = page.name;
                var html = page.html;

                $('#page-list').append('<li><a href="http://localhost:8080/home/staticpage/' + id + '">' + name + '</a></li>');
            })
        },
        error: function(){
            $('#error-messages').append('<li>Error contacting database. Please try again later.</li>');
        }
    })
})