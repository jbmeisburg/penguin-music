﻿$(document).ready(function () {
    $('#tag-field').hide();
    $('#category-select').hide();
    $('#tags').hide();
    $('#approved-field').hide();
    $('#schedule-field').hide();
    $('#expire-date').hide();
    $('#tag-button').hide();
    $('#input-fields').hide();

    var url = window.location.href;
    var passid = url.substring(url.lastIndexOf('/') + 1);

    $.ajax({
        type: 'get',
        url: 'http://localhost:8080/pages',
        success: function (pageArray) {
            $.each(pageArray, function (index, page) {
                if (page.id == passid) {
                    var id = page.id;
                    var name = page.name;
                    var html = page.html;

                    $('#id-field').val(passid);
                    $('#title').val(name);
                    tinyMCE.get('post-body').setContent(html);
                }
            });
        },
        error: function () {
            $('#error-messages').append('<li>Error contacting database. Please try again later.</li>');
        }
    })
});

$('#save-post').click(function () {
    //var tags = $(".dist-tag");
    //var tagArray = [];
    //$.each(tags, function (i, v) {
    //    tagArray.push(v.innerText);
    //});

    //if (tagArray.length == 0) {
    //    tagArray = null;
    //}

    tinyMCE.triggerSave();

    $.ajax({
        type: 'POST',
        url: 'http://localhost:8080/page/update',
        data: JSON.stringify({
            id: $('#id-field').val(),
            name: $('#title').val(),
            html: $('#post-body').val(),
        }),
        headers: {
        //    'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        //'dataType': 'json',
        success: function () {
            //$('#title').val('');
            //$('#post-body').val('');
            //$('#approved-field').val('');
            //$('#schedule-field').val('');
            //$('#expire-field').val('');

            window.location.replace('http://localhost:8080');

        },
        error: function (response) {
            $('#error-messages').append(response.responseJSON.message);
        }
    })
});

$('#tag-button').click(function () {
    if ($('#tag-field').val() != '') {
        $('#tags').append($('<button>').attr({ class: 'dist-tag label label-default' }).attr({ style: 'margin:2px' }).attr({ id: 'dist-tag' }).text($('#tag-field').val()));
        $('#tag-field').val('');
    }
});

$('body').on('click', '#dist-tag', function () {
    this.remove();
});

$('#delete-post').click(function () {
    bootbox.confirm({
        size: "small",
        title: "Delete Page",
        message: "Are you sure you want to delete this page? It will be gone forever!",
        callback: function (result) {
            if (result == true) {
                $.ajax({
                    type: 'post',
                    url: 'http://localhost:8080/page/delete/' + $('#id-field').val(),
                    success: function () {
                        window.location.replace('http://localhost:8080');
                    },
                    error: function () {
                        $('#error-messages').append('<li>Error calling databse. Please try again later.</li>');
                    }
                })
            }
        }
    })
});

$('#cancel-post').click(function () {
    window.location.replace('http://localhost:8080');
})