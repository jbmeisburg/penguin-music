﻿//Previous version:
//
//tinymce.init({
//    selector: 'textarea',
//    height: 500,
//    menubar: false,
//    plugins: [
//      'advlist autolink lists link image charmap print preview anchor',
//      'searchreplace visualblocks code fullscreen',
//      'insertdatetime media table contextmenu paste code'
//    ],
//    toolbar: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
//    content_css: '//www.tinymce.com/css/codepen.min.css'
//});

tinymce.init({
    selector: 'textarea',
    height: 500,
    menubar: false,
    plugins: ['image',
        'advlist autolink lists link image charmap print preview anchor',
        'searchreplace visualblocks code fullscreen',
        'insertdatetime media table contextmenu paste code'
    ],
    toolbar: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
    content_css: '//www.tinymce.com/css/codepen.min.css',
    file_browser_callback: function (field_name, url, type, win) {
        if (type == 'image') {
            $('#my_form input').click();
        }
    }//,
    //file_picker_callback: function (callback, value, meta) {
    //    if (meta.filetype == 'image') {
    //        var input = document.getElementById('image');
    //        input.click();
    //        input.onchange = function () {
    //            var file = input.files[0];
    //            var reader = new FileReader();
    //            reader.onload = function (e) {
    //                callback(e.target.result, {
    //                    alt: file.name
    //                });
    //            };
    //            reader.readAsDataURL(file);
    //        };
    //    }
    //}
});
//Thanks Stack Overflow: 'https://tinyurl.com/mnerrbj'
