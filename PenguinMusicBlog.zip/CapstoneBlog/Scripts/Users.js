﻿$(document).ready(function () {
    $.ajax({
        type: 'get',
        url: idklol,
        success: function (userArray) {
            $.each(userArray, function (index, user) {
                var name = user.name;
                var email = user.email;
                var role = user.role;

                var row = '<tr>';
                row += '<td>' + name + '</td>';
                row += '<td>' + role + '</td>';
                row += '<td><a href="#">Edit</a></td>';

                $('#table-body').append(row);
            })
        },
        error: function () {
            $('#error-messages'.append('<li>Error contacting database. Please try again later.</li>'));
        }
    })
});