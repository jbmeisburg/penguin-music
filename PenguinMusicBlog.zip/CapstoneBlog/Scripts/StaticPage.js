﻿$(document).ready(function () {
    var url = window.location.href;
    var passid = url.substring(url.lastIndexOf('/') + 1);
    $('#edit-link').append('<a href="http://localhost:8080/home/editpage/' + passid + '">Edit this page</a>')
    $.ajax({
        type: 'get',
        url: 'http://localhost:8080/pages',
        success: function (pageArray) {
            $.each(pageArray, function (index, page) {
                if (page.id == passid) {
                    var id = page.id;
                    var name = page.name;
                    var html = page.html;

                    $('#title').append(name);
                    $('#page-body').append(html);
                }
            });
        },
        error: function () {
            $('#error-messages').append('<li>Error contacting database. Please try again later.</li>');
        }
    })
});