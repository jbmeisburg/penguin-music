﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using CapstoneBlog.Models;
using CapstoneBlog.Data;
using CapstoneBlog.BLL;

namespace CapstoneBlog.Tests
{
    [TestFixture]
    class PageManagerTests
    {
        PageManager _pm;

        public Page GeneratePage()
        {
            return new Page()
            {
                Id = -1,
                Name = "Title",
                HTML = "HTML Content."
            };
        }

        [SetUp]
        public void SetUp()
        {
            _pm = new PageManager(new MockPageRepo());

        }
        [Test]
        public void AddPageTest()
        {
            _pm.AddPage(new Page()
            {
                Id = -1,
                Name = "Title",
                HTML = "HTML Content."
            });
            _pm.AddPage(new Page()
            {
                Id = -1,
                Name = "Title 2",
                HTML = "HTML Content 2."
            });

            List<Page> pages = _pm.GetAllPages().ToList();
            Assert.AreEqual(2, pages.Count());
            Assert.AreEqual(1, pages.First().Id);
            Assert.AreEqual(2, pages.Last().Id);
        }

        [Test]
        public void DeletePageTest()
        {
            _pm.AddPage(GeneratePage());
            _pm.AddPage(GeneratePage());
            _pm.AddPage(GeneratePage());
            Assert.AreEqual(3, _pm.GetAllPages().Count());
            _pm.DeletePage(2);
            _pm.DeletePage(2); //Redundant
            Assert.AreEqual(2, _pm.GetAllPages().Count());
            _pm.DeletePage(1);
            _pm.DeletePage(3);
            Assert.AreEqual(0, _pm.GetAllPages().Count());
        }

        [Test]
        public void UpdatePageTest()
        {
            int id = _pm.AddPage(GeneratePage());

            Page newPage = GeneratePage();
            newPage.Id = id;
            newPage.Name = "Updated";
            _pm.UpdatePage(newPage);

            Page anotherPage = GeneratePage();
            anotherPage.Id = 500;
            anotherPage.Name = "Ignored";
            _pm.UpdatePage(anotherPage); //nothing should be updated

            Assert.AreEqual(1, _pm.GetAllPages().Count());
            Assert.AreEqual("Updated", _pm.GetAllPages().Last().Name);
        }
    }
}
