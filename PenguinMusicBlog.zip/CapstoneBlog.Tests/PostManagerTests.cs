﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using CapstoneBlog.Models;
using CapstoneBlog.Data;
using CapstoneBlog.BLL;

namespace CapstoneBlog.Tests
{
    /*NOTE: Although Post ID should be handled by repo methods, nothing
     * else is handling the IDs of Authors, Categories or Tags in these tests, and they are set arbitrarily to -1.*/

    [TestFixture]
    class PostManagerTests
    {
        PostManager _pm;

        [SetUp]
        public void SetUpEmpty()
        {
            _pm = new PostManager(new MockPostRepo());
        }

        private Post GeneratePost(string title, string category)
        {
            return new Post()
            {
                Title = title,
                Content = "Caveat emptor lorem ipsum et cetera",
                Author = new User() { Id = 1, UserName = "OwnerLady" },
                Category = new Category() { Id = -1, Name = category },
                Tags = null,
                PostDate = new DateTime(2017, 1, 23),
                ExpirationDate = new DateTime(2017, 4, 13),
                Approved = true
            };
        }

        private Post AddTags(Post post, params string[] tagNames)
        {
            List<Tag> tags = new List<Tag>();
            foreach (string tagName in tagNames)
            {
                tags.Add(new Tag() { Id = -1, Name = tagName });
            }
            post.Tags = tags;
            return post;
        }

        [Test]
        public void AddPostTest()
        {
            _pm.AddPost(GeneratePost("Title One", "Titles"));
            _pm.AddPost(GeneratePost("Title Two", "Titles"));
            List<Post> posts = _pm.GetAllPosts().ToList();

            Assert.AreEqual(2, posts.Count());
            Assert.AreEqual(1, posts.First().Id);
            Assert.AreEqual(2, posts.Last().Id);
        }

        [Test]
        public void DeletePostTest()
        {
            int id = _pm.AddPost(GeneratePost("Title One", "Titles"));
            _pm.DeletePost(id + 1);
            Assert.AreEqual(1, _pm.GetAllPosts().Count());
            _pm.DeletePost(id);
            Assert.AreEqual(0, _pm.GetAllPosts().Count());
        }

        [Test]
        public void UpdatePostTest()
        {
            int id = _pm.AddPost(GeneratePost("Title One", "Titles"));
            Post post = GeneratePost("Title Two", "Titles");
            post.Id = id;
            _pm.UpdatePost(post);

            Post anotherPost = GeneratePost("Something else", "Entirely");
            anotherPost.Id = 500;
            anotherPost.Title = "Something else";
            _pm.UpdatePost(anotherPost); //nothing should be updated

            Assert.AreEqual(1, _pm.GetAllPosts().Count());
            Assert.AreEqual(0, _pm.SearchPosts("title", "One").Count());
            Assert.AreEqual(1, _pm.SearchPosts("title", "Two").Count());
        }

        [Test]
        public void GetPostTest()
        {
            int id1 = _pm.AddPost(GeneratePost("Title One", "Whatever"));
            int id2 = _pm.AddPost(GeneratePost("Title Two", "Etc."));

            Assert.AreEqual("Title One", _pm.GetPost(id1).Title);
            Assert.AreEqual("Title Two", _pm.GetPost(id2).Title);
        }

        [Test]
        public void GetAllPostsTest()
        {
            int id1 = _pm.AddPost(GeneratePost("Title One", "Whatever"));
            int id2 = _pm.AddPost(GeneratePost("Title Two", "Etc."));

            Assert.AreEqual(2, _pm.GetAllPosts().Count());
        }

        [Test]
        public void GetAllCategoriesTest()
        {
            _pm.AddPost(GeneratePost("Title One", "Whatever"));
            _pm.AddPost(GeneratePost("Title Two", "Etc."));
            _pm.AddPost(GeneratePost("Title Three", "Etc."));
            _pm.AddPost(GeneratePost("Title Four", "Okay"));
            _pm.AddPost(GeneratePost("Title Five", "Whatever"));

            Assert.AreEqual(3, _pm.GetAllCategories().Count());
        }

        [Test]
        public void GetAllTagsTest()
        {
            Post post = GeneratePost("Title One", "Whatever");
            AddTags(post, "One", "Two");
            _pm.AddPost(post);

            post = GeneratePost("Title Two", "Whatever");
            AddTags(post, "Four", "Five", "Six");
            _pm.AddPost(post);

            post = GeneratePost("Title Three", "Okay");
            AddTags(post, "Two", "Three");
            _pm.AddPost(post);

            Assert.AreEqual(6, _pm.GetAllTags().Count());
        }

        //See hardcoded data in method body
        [TestCase(false, 0, 0, 0, 3)] //Return all
        [TestCase(true, 0, 0, 0, 2)] //Return all approved on any date
        [TestCase(false, 2017, 1, 22, 0)] //Too soon
        [TestCase(false, 2017, 3, 12, 2)] //Two posted, none expired
        [TestCase(false, 2017, 3, 13, 1)] //Two posted, one expired
        [TestCase(false, 2017, 3, 23, 2)] //All posted, one expired
        [TestCase(true, 2017, 3, 12, 1)] //Two posted, one not approved
        [TestCase(true, 2017, 12, 12, 1)] //All posted, two expired

        public void GetAndSearchValidPostsTest(bool approvedOnly, int year, int month, int day, int expectedPosts)
        {
            Post post = GeneratePost("Title One", "Whatever");
            post.PostDate = new DateTime(2017, 1, 23);
            post.ExpirationDate = new DateTime(2017, 4, 13);
            post.Approved = true;
            _pm.AddPost(post);

            post = GeneratePost("Title Two", "Whatever");
            post.PostDate = new DateTime(2017, 2, 23);
            post.ExpirationDate = new DateTime(2017, 3, 13);
            post.Approved = false;
            _pm.AddPost(post);

            post = GeneratePost("Title Three", "Something Else");
            post.PostDate = new DateTime(2017, 3, 23);
            post.ExpirationDate = null;
            post.Approved = true;
            _pm.AddPost(post);

            DateTime? onDate;
            if (year < 1 || month < 1 || day < 1)
            {
                onDate = null;
            }
            else
            {
                onDate = new DateTime(year, month, day);
            }

            Assert.AreEqual(expectedPosts, _pm.GetAllPosts(approvedOnly, onDate).Count());
            Assert.AreEqual(expectedPosts, _pm.SearchPosts("title", "title",
                approvedOnly, onDate).Count());
        }
    }
}