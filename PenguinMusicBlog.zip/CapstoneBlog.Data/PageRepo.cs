﻿using CapstoneBlog.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapstoneBlog.Data
{
    public class PageRepo : IPageRepo
    {
        public int AddPage(Page page)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandText = "AddPage";

                cmd.Parameters.AddWithValue("@PageName", page.Name);
                cmd.Parameters.AddWithValue("@PageHTML", page.HTML);

                conn.Open();
                cmd.ExecuteNonQuery();
            }

            return page.Id;
        }

        public void DeletePage(int id)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandText = "DeletePage";

                cmd.Parameters.AddWithValue("@PageID", id);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public IEnumerable<Page> GetAllPages()
        {
            List<Page> pages = new List<Page>();

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandText = "GetAllPages";

                conn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Page page = new Page();

                        page.Name = dr["PageName"].ToString();
                        page.HTML = dr["PageHTML"].ToString();

                        pages.Add(page);
                    }
                }
            }

            return pages;
        }

        public Page GetPage(int id)
        {
            List<Page> pages = new List<Page>();

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandText = "GetAllPages";

                conn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Page page = new Page();

                        page.Name = dr["PageName"].ToString();
                        page.HTML = dr["PageHTML"].ToString();

                        pages.Add(page);
                    }
                }
            }

            return pages.FirstOrDefault();
        }

        public void LoadDemo()
        {
            throw new NotImplementedException();
        }

        public void UpdatePage(Page page)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandText = "EditPage";

                cmd.Parameters.AddWithValue("@PageID", page.Id);
                cmd.Parameters.AddWithValue("@PageName", page.Name);
                cmd.Parameters.AddWithValue("@PageHTML", page.HTML);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }
    }
}
