﻿using CapstoneBlog.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapstoneBlog.Data
{
    public class ADORepo : IPostRepo
    {
        public int AddPost(Post post)
        {
            //post.Tags = new List<Tag>();

            using (SqlConnection conn = new SqlConnection())
            {
                
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandText = "CreateBlogPost";
                
                cmd.Parameters.AddWithValue("@UserName", post.Author.UserName);
                try
                {
                    cmd.Parameters.AddWithValue("@PostTitle", post.Title);
                }
                catch (Exception ex)
                {
                    ArgumentException argEx = new ArgumentException("Title cannot be left blank.", ex);
                    throw argEx;
                }
                try
                {
                    cmd.Parameters.AddWithValue("@PostDate", post.PostDate);
                }
                catch (Exception ex)
                {
                    ArgumentException argEx = new ArgumentException("Enter a valid current or future date.", ex);
                    throw argEx;
                }
                try
                {
                    cmd.Parameters.AddWithValue("@PostContent", post.Content);
                }
                catch (Exception ex)
                {
                    ArgumentException argEx = new ArgumentException("Content cannot be left blank.", ex);
                    throw argEx;
                }

                if (post.ExpirationDate != null)
                {
                    cmd.Parameters.AddWithValue("@ExpirationDate", post.ExpirationDate);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@ExpirationDate", DBNull.Value);
                }

                try
                {
                    cmd.Parameters.AddWithValue("@CategoryName", post.Category.Name);
                }
                catch (Exception ex)
                {
                    ArgumentException argEx = new ArgumentException("Please enter a valid category", ex);
                    throw argEx;
                }
                
                cmd.Parameters.AddWithValue("@Approval", post.Approved);
                conn.Open();
                post.Id = int.Parse(cmd.ExecuteScalar().ToString()); //Add the post without tags first

                List<string> existingTags = GetAllTags().ToList();

                foreach (var tag in post.Tags)
                {
                    //Handle tags that don't exist in db yet:
                    if (!existingTags.Any(t => t == tag.Name))
                    {
                        cmd.CommandText = "CreateTag";
                        cmd.Parameters.Clear();
                        cmd.Parameters.AddWithValue("@TagName", tag.Name);
                        cmd.ExecuteScalar();
                    }

                    using (SqlCommand cmd2 = new SqlCommand("AddTagToPost", conn))
                    {

                        cmd2.CommandType = CommandType.StoredProcedure;
                        cmd2.Parameters.AddWithValue("@PostID", post.Id);
                        cmd2.Parameters.AddWithValue("@TagName", tag.Name);
                        cmd2.CommandText = "AddTagToPost";
                        cmd2.ExecuteScalar();
                        //using (SqlDataReader dr = cmd2.ExecuteReader())
                        //{
                        //    while (dr.Read())
                        //    {
                        //        post.Tags.Add(new Tag() { Name = dr["TagName"].ToString() });
                        //    }
                        //}
                    }
                }
            }         
            return 0; //Return value not used, oh well
        }

        private void AddTag(Tag tag)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandText = "CreateTag";

                cmd.Parameters.AddWithValue("@TagName", tag.Name);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public void DeletePost(int id)
        {
            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandText = "DeleteBlogPost";

                cmd.Parameters.AddWithValue("@PostID", id);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public IEnumerable<String> GetAllCategories()
        {
            List<string> categories = new List<string>();

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandText = "GetAllCategories";

                conn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        var c = dr["CategoryName"].ToString();

                        categories.Add(c);
                    }
                }
            }

            return categories.AsEnumerable();
        }

        public IEnumerable<Post> GetAllPosts(bool approvedOnly = true, DateTime? onDate = default(DateTime?))
        {
            Func<Post, bool> valid = p =>
            ((!approvedOnly || p.Approved == true) &&
            (onDate == null ||
                ((p.ExpirationDate == null || p.ExpirationDate > onDate) &&
                p.PostDate <= onDate)));

            List<Post> posts = new List<Post>();

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                conn.Open();

                using (SqlCommand cmd = new SqlCommand("GetAllPosts", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "GetAllPosts";
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                Post post = new Post();
                                post.Author = new User();
                                post.Category = new Category();
                                post.Tags = new List<Tag>();

                                post.Id = (int)dr["PostID"];
                                post.Author.UserName = dr["UserName"].ToString();
                                post.Title = dr["PostTitle"].ToString();
                                post.Content = dr["PostContent"].ToString();
                                post.PostDate = (DateTime)dr["PostDate"];
                                post.Approved = (bool)dr["Approval"];
                                if (dr["ExpirationDate"] != DBNull.Value)
                                    post.ExpirationDate = (DateTime)dr["ExpirationDate"];
                                post.Category.Name = dr["CategoryName"].ToString();

                                posts.Add(post);
                            }
                        }
                }

                foreach(var p in posts)
                {
                    using (SqlCommand cmd2 = new SqlCommand("GetTagsByPostID", conn))
                    {
                        cmd2.CommandType = CommandType.StoredProcedure;
                        cmd2.Parameters.AddWithValue("@PostID", p.Id);

                        using (SqlDataReader dr = cmd2.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                p.Tags.Add(new Tag() { Name = dr["TagName"].ToString() });
                            }
                        }


                    }
                }
            }
            
            return posts;
            
        }

        public IEnumerable<String> GetAllTags()
        {
            List<string> tags = new List<string>();

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandText = "GetAllTags";

                conn.Open();
                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {

                        var t = dr["TagName"].ToString();

                        tags.Add(t);
                    }
                }
            }

            return tags.AsEnumerable();
        }

        public Post GetPost(int id)
        {
            List<Post> posts = new List<Post>();

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                conn.Open();

                using (SqlCommand cmd = new SqlCommand("GetPostById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "GetPostById";
                    cmd.Parameters.AddWithValue("@PostID", id);
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Post post = new Post();
                            post.Author = new User();
                            post.Category = new Category();
                            post.Tags = new List<Tag>();

                            post.Id = (int)dr["PostID"];
                            post.Author.UserName = dr["UserName"].ToString();
                            post.Title = dr["PostTitle"].ToString();
                            post.Content = dr["PostContent"].ToString();
                            post.PostDate = (DateTime)dr["PostDate"];
                            post.Approved = (bool)dr["Approval"];
                            if (dr["ExpirationDate"] != DBNull.Value)
                                post.ExpirationDate = (DateTime)dr["ExpirationDate"];
                            post.Category.Name = dr["CategoryName"].ToString();

                            posts.Add(post);
                        }
                    }
                }

                foreach (var p in posts)
                {
                    using (SqlCommand cmd2 = new SqlCommand("GetTagsByPostID", conn))
                    {
                        cmd2.CommandType = CommandType.StoredProcedure;
                        cmd2.Parameters.AddWithValue("@PostID", p.Id);

                        using (SqlDataReader dr1 = cmd2.ExecuteReader())
                        {
                            while (dr1.Read())
                            {
                                p.Tags.Add(new Tag() { Name = dr1["TagName"].ToString() });
                            }
                        }


                    }
                }
            }

            return posts.FirstOrDefault();
        }

        public void LoadDemo()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Post> SearchPosts(string field, string searchTerm, bool approvedOnly = true, DateTime? onDate = default(DateTime?))
        {
            Func<Post, bool> valid = p =>
                ((!approvedOnly || p.Approved == true) &&
                (onDate == null ||
                    ((p.ExpirationDate == null || p.ExpirationDate > onDate) &&
                    p.PostDate <= onDate)));

            List<Post> posts = new List<Post>();

            switch (field.ToLower())
            {
                case "title":
                    using (SqlConnection conn = new SqlConnection())
                    {
                        conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                        conn.Open();

                        using (SqlCommand cmd = new SqlCommand("GetAllPosts", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "SearchPostsByTitle";
                            cmd.Parameters.AddWithValue("@PostTitle", searchTerm.ToLower());
                            using (SqlDataReader dr = cmd.ExecuteReader())
                            {
                                while (dr.Read())
                                {
                                    Post post = new Post();
                                    post.Author = new User();
                                    post.Category = new Category();
                                    post.Tags = new List<Tag>();

                                    post.Id = (int)dr["PostID"];
                                    post.Author.UserName = dr["UserName"].ToString();
                                    post.Title = dr["PostTitle"].ToString();
                                    post.Content = dr["PostContent"].ToString();
                                    post.PostDate = (DateTime)dr["PostDate"];
                                    post.Approved = (bool)dr["Approval"];
                                    if (dr["ExpirationDate"] != DBNull.Value)
                                        post.ExpirationDate = (DateTime)dr["ExpirationDate"];
                                    post.Category.Name = dr["CategoryName"].ToString();

                                    posts.Add(post);
                                }
                            }
                        }

                        foreach (var p in posts)
                        {
                            using (SqlCommand cmd2 = new SqlCommand("GetTagsByPostID", conn))
                            {
                                cmd2.CommandType = CommandType.StoredProcedure;
                                cmd2.Parameters.AddWithValue("@PostID", p.Id);

                                using (SqlDataReader dr = cmd2.ExecuteReader())
                                {
                                    while (dr.Read())
                                    {
                                        p.Tags.Add(new Tag() { Name = dr["TagName"].ToString() });
                                    }
                                }


                            }
                        }
                    }

                    return posts;
                case "category":
                    using (SqlConnection conn = new SqlConnection())
                    {
                        conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                        conn.Open();

                        using (SqlCommand cmd = new SqlCommand("GetAllPosts", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "SearchPostsByCategory";
                            cmd.Parameters.AddWithValue("@CategoryName", searchTerm.ToLower());
                            using (SqlDataReader dr = cmd.ExecuteReader())
                            {
                                while (dr.Read())
                                {
                                    Post post = new Post();
                                    post.Author = new User();
                                    post.Category = new Category();
                                    post.Tags = new List<Tag>();

                                    post.Id = (int)dr["PostID"];
                                    post.Author.UserName = dr["UserName"].ToString();
                                    post.Title = dr["PostTitle"].ToString();
                                    post.Content = dr["PostContent"].ToString();
                                    post.PostDate = (DateTime)dr["PostDate"];
                                    post.Approved = (bool)dr["Approval"];
                                    if (dr["ExpirationDate"] != DBNull.Value)
                                        post.ExpirationDate = (DateTime)dr["ExpirationDate"];
                                    post.Category.Name = dr["CategoryName"].ToString();

                                    posts.Add(post);
                                }
                            }
                        }

                        foreach (var p in posts)
                        {
                            using (SqlCommand cmd2 = new SqlCommand("GetTagsByPostID", conn))
                            {
                                cmd2.CommandType = CommandType.StoredProcedure;
                                cmd2.Parameters.AddWithValue("@PostID", p.Id);

                                using (SqlDataReader dr = cmd2.ExecuteReader())
                                {
                                    while (dr.Read())
                                    {
                                        p.Tags.Add(new Tag() { Name = dr["TagName"].ToString() });
                                    }
                                }


                            }
                        }
                    }

                    return posts;
                case "tag":
                    using (SqlConnection conn = new SqlConnection())
                    {
                        conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                        conn.Open();

                        using (SqlCommand cmd = new SqlCommand("GetAllPosts", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "SearchPostsByTag";
                            cmd.Parameters.AddWithValue("@TagName", searchTerm.ToLower());
                            using (SqlDataReader dr = cmd.ExecuteReader())
                            {
                                while (dr.Read())
                                {
                                    Post post = new Post();
                                    post.Author = new User();
                                    post.Category = new Category();
                                    post.Tags = new List<Tag>();

                                    post.Id = (int)dr["PostID"];
                                    post.Author.UserName = dr["UserName"].ToString();
                                    post.Title = dr["PostTitle"].ToString();
                                    post.Content = dr["PostContent"].ToString();
                                    post.PostDate = (DateTime)dr["PostDate"];
                                    post.Approved = (bool)dr["Approval"];
                                    if (dr["ExpirationDate"] != DBNull.Value)
                                        post.ExpirationDate = (DateTime)dr["ExpirationDate"];
                                    post.Category.Name = dr["CategoryName"].ToString();

                                    posts.Add(post);
                                }
                            }
                        }

                        foreach (var p in posts)
                        {
                            using (SqlCommand cmd2 = new SqlCommand("GetTagsByPostID", conn))
                            {
                                cmd2.CommandType = CommandType.StoredProcedure;
                                cmd2.Parameters.AddWithValue("@PostID", p.Id);

                                using (SqlDataReader dr = cmd2.ExecuteReader())
                                {
                                    while (dr.Read())
                                    {
                                        p.Tags.Add(new Tag() { Name = dr["TagName"].ToString() });
                                    }
                                }


                            }
                        }
                    }

                    return posts;
                case "author":
                    using (SqlConnection conn = new SqlConnection())
                    {
                        conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                        conn.Open();

                        using (SqlCommand cmd = new SqlCommand("GetAllPosts", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "SearchPostsByUser";
                            cmd.Parameters.AddWithValue("@UserName", searchTerm.ToLower());
                            using (SqlDataReader dr = cmd.ExecuteReader())
                            {
                                while (dr.Read())
                                {
                                    Post post = new Post();
                                    post.Author = new User();
                                    post.Category = new Category();
                                    post.Tags = new List<Tag>();

                                    post.Id = (int)dr["PostID"];
                                    post.Author.UserName = dr["UserName"].ToString();
                                    post.Title = dr["PostTitle"].ToString();
                                    post.Content = dr["PostContent"].ToString();
                                    post.PostDate = (DateTime)dr["PostDate"];
                                    post.Approved = (bool)dr["Approval"];
                                    if (dr["ExpirationDate"] != DBNull.Value)
                                        post.ExpirationDate = (DateTime)dr["ExpirationDate"];
                                    post.Category.Name = dr["CategoryName"].ToString();

                                    posts.Add(post);
                                }
                            }
                        }

                        foreach (var p in posts)
                        {
                            using (SqlCommand cmd2 = new SqlCommand("GetTagsByPostID", conn))
                            {
                                cmd2.CommandType = CommandType.StoredProcedure;
                                cmd2.Parameters.AddWithValue("@PostID", p.Id);

                                using (SqlDataReader dr = cmd2.ExecuteReader())
                                {
                                    while (dr.Read())
                                    {
                                        p.Tags.Add(new Tag() { Name = dr["TagName"].ToString() });
                                    }
                                }


                            }
                        }
                    }

                    return posts;
                case "content":
                    using (SqlConnection conn = new SqlConnection())
                    {
                        conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                        conn.Open();

                        using (SqlCommand cmd = new SqlCommand("GetAllPosts", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "SearchPostsByContent";
                            cmd.Parameters.AddWithValue("@PostContent", searchTerm.ToLower());
                            using (SqlDataReader dr = cmd.ExecuteReader())
                            {
                                while (dr.Read())
                                {
                                    Post post = new Post();
                                    post.Author = new User();
                                    post.Category = new Category();
                                    post.Tags = new List<Tag>();

                                    post.Id = (int)dr["PostID"];
                                    post.Author.UserName = dr["UserName"].ToString();
                                    post.Title = dr["PostTitle"].ToString();
                                    post.Content = dr["PostContent"].ToString();
                                    post.PostDate = (DateTime)dr["PostDate"];
                                    post.Approved = (bool)dr["Approval"];
                                    if (dr["ExpirationDate"] != DBNull.Value)
                                        post.ExpirationDate = (DateTime)dr["ExpirationDate"];
                                    post.Category.Name = dr["CategoryName"].ToString();

                                    posts.Add(post);
                                }
                            }
                        }

                        foreach (var p in posts)
                        {
                            using (SqlCommand cmd2 = new SqlCommand("GetTagsByPostID", conn))
                            {
                                cmd2.CommandType = CommandType.StoredProcedure;
                                cmd2.Parameters.AddWithValue("@PostID", p.Id);

                                using (SqlDataReader dr = cmd2.ExecuteReader())
                                {
                                    while (dr.Read())
                                    {
                                        p.Tags.Add(new Tag() { Name = dr["TagName"].ToString() });
                                    }
                                }


                            }
                        }
                    }

                    return posts;
                case "date":
                    using (SqlConnection conn = new SqlConnection())
                    {
                        conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                        conn.Open();

                        using (SqlCommand cmd = new SqlCommand("GetAllPosts", conn))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "SearchPostsByDate";
                            cmd.Parameters.AddWithValue("@PostDate", searchTerm.ToLower());
                            using (SqlDataReader dr = cmd.ExecuteReader())
                            {
                                while (dr.Read())
                                {
                                    Post post = new Post();
                                    post.Author = new User();
                                    post.Category = new Category();
                                    post.Tags = new List<Tag>();

                                    post.Id = (int)dr["PostID"];
                                    post.Author.UserName = dr["UserName"].ToString();
                                    post.Title = dr["PostTitle"].ToString();
                                    post.Content = dr["PostContent"].ToString();
                                    post.PostDate = (DateTime)dr["PostDate"];
                                    post.Approved = (bool)dr["Approval"];
                                    if (dr["ExpirationDate"] != DBNull.Value)
                                        post.ExpirationDate = (DateTime)dr["ExpirationDate"];
                                    post.Category.Name = dr["CategoryName"].ToString();

                                    posts.Add(post);
                                }
                            }
                        }

                        foreach (var p in posts)
                        {
                            using (SqlCommand cmd2 = new SqlCommand("GetTagsByPostID", conn))
                            {
                                cmd2.CommandType = CommandType.StoredProcedure;
                                cmd2.Parameters.AddWithValue("@PostID", p.Id);

                                using (SqlDataReader dr = cmd2.ExecuteReader())
                                {
                                    while (dr.Read())
                                    {
                                        p.Tags.Add(new Tag() { Name = dr["TagName"].ToString() });
                                    }
                                }


                            }
                        }
                    }

                    return posts;
                default:
                    return null;
            }

        }

        public void UpdatePost(Post post)
        {
            if (post.Tags != null)
            {
                List<Tag> postTags = post.Tags;

                using (SqlConnection conn1 = new SqlConnection())
                {
                    conn1.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                    SqlCommand cmd1 = new SqlCommand();
                    cmd1.Connection = conn1;
                    cmd1.CommandText = "DELETE FROM PostTag " +
                                        "WHERE PostID = @PostID";

                    cmd1.Parameters.AddWithValue("@PostID", post.Id);

                    conn1.Open();
                    cmd1.ExecuteNonQuery();
                }

                List<Tag> allTags = new List<Tag>();

                using (SqlConnection conn2 = new SqlConnection())
                {
                    conn2.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                    SqlCommand cmd2 = new SqlCommand();
                    cmd2.Connection = conn2;
                    cmd2.CommandText = "SELECT * FROM Tag";

                    conn2.Open();

                    using (SqlDataReader dr = cmd2.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            Tag tag = new Tag();

                            tag.Name = dr["TagName"].ToString();

                            allTags.Add(tag);
                        }
                    }
                }

                foreach (var tag in postTags)
                {
                    if (allTags.Any(t => t.Name == tag.Name))
                    {
                        using (SqlConnection conn3 = new SqlConnection())
                        {
                            conn3.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                            SqlCommand cmd3 = new SqlCommand();
                            cmd3.Connection = conn3;
                            cmd3.CommandType = CommandType.StoredProcedure;

                            cmd3.CommandText = "AddTagToPost";

                            cmd3.Parameters.AddWithValue("@PostID", post.Id);
                            cmd3.Parameters.AddWithValue("@TagName", tag.Name);

                            conn3.Open();
                            cmd3.ExecuteNonQuery();
                        }
                    }

                    else
                    {
                        using (SqlConnection conn4 = new SqlConnection())
                        {
                            conn4.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                            SqlCommand cmd4 = new SqlCommand();
                            cmd4.Connection = conn4;
                            cmd4.CommandType = CommandType.StoredProcedure;

                            cmd4.CommandText = "CreateTag";

                            cmd4.Parameters.AddWithValue("@TagName", tag.Name);

                            conn4.Open();
                            cmd4.ExecuteNonQuery();
                        }

                        using (SqlConnection conn3 = new SqlConnection())
                        {
                            conn3.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                            SqlCommand cmd3 = new SqlCommand();
                            cmd3.Connection = conn3;
                            cmd3.CommandType = CommandType.StoredProcedure;

                            cmd3.CommandText = "AddTagToPost";

                            cmd3.Parameters.AddWithValue("@PostID", post.Id);
                            cmd3.Parameters.AddWithValue("@TagName", tag.Name);

                            conn3.Open();
                            cmd3.ExecuteNonQuery();
                        }
                    }
                } 
            }

            using (SqlConnection conn = new SqlConnection())
            {
                conn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandText = "EditBlogPost";

                cmd.Parameters.AddWithValue("@PostID", post.Id);
                cmd.Parameters.AddWithValue("@PostTitle", post.Title);
                cmd.Parameters.AddWithValue("@Approval", post.Approved);
                cmd.Parameters.AddWithValue("@PostContent", post.Content);

                if (post.ExpirationDate != null)
                {
                    cmd.Parameters.AddWithValue("@ExpirationDate", post.ExpirationDate);
                }
                else
                {
                    cmd.Parameters.AddWithValue("@ExpirationDate", DBNull.Value);
                }

                cmd.Parameters.AddWithValue("@CategoryName", post.Category.Name);

                conn.Open();

                cmd.ExecuteNonQuery();
            }
        }
    }
}
