﻿using CapstoneBlog.Models;
using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace CapstoneBlog.Data
{
    public class MockPostRepo : IPostRepo
    {
        List<Post> _posts = new List<Post>();

        public void LoadDemo()
        {
            _posts = new List<Post>();
            AddPost(new Post()
            {
                Title = "Post One",
                Content = "Caveat emptor lorem ipsum et cetera",
                Author = new User() { Id = 1, UserName = "User One" },
                Category = new Category() { Id = 1, Name = "Funsies" },
                Tags = new List<Tag>()
            });
            _posts.Last().Tags.Add(new Tag()
            {
                Id = 1,
                Name = "YOLO"
            });
            _posts.Last().Tags.Add(new Tag()
            {
                Id = 2,
                Name = "WTF"
            });
            AddPost(new Post()
            {
                Title = "Post Two",
                Content = "Cetera et ipsum lorem emptor caveat",
                Author = new User() { Id = 2, UserName = "User Two" },
                Category = new Category() { Id = 1, Name = "No Funsies" },
                Tags = new List<Tag>()
            });
            _posts.Last().Tags.Add(new Tag()
            {
                Id = 1,
                Name = "YOLO"
            });
        }

        public int AddPost(Post post)
        {
            Post last = _posts.LastOrDefault();
            if (last == null)
                post.Id = 1;
            else
                post.Id = last.Id + 1;
            _posts.Add(post);
            return post.Id;
        }

        public void DeletePost(int id)
        {
            _posts.RemoveAll(p => p.Id == id);
        }

        public IEnumerable<String> GetAllCategories()
        {
            //List<String> categories = new List<String>();
            //categories.Add("Category One");
            //categories.Add("Category Two");
            //return categories;
            return _posts.Select(p => p.Category.Name).Distinct();
        }

        public IEnumerable<Post> GetAllPosts(bool approvedOnly = true, DateTime? onDate = null)
        {
            return _posts.Where(p => ((!approvedOnly || p.Approved == true) &&
                (onDate == null ||
                    ((p.ExpirationDate == null || p.ExpirationDate > onDate) &&
                    p.PostDate <= onDate))));
        }

        public IEnumerable<String> GetAllTags()
        {
            return _posts.SelectMany(p => p.Tags).Select(t => t.Name).Distinct();
        }

        public Post GetPost(int id)
        {
            return _posts.FirstOrDefault(p => p.Id == id);
        }

        public void UpdatePost(Post post)
        {
            if (_posts.RemoveAll(p => p.Id == post.Id) >= 1)
                _posts.Add(post);
        }

        public IEnumerable<Post> SearchPosts(string field, string searchTerm, bool approvedOnly = true, DateTime? onDate = null)
        {
            Func<Post, bool> valid = p =>
                ((!approvedOnly || p.Approved == true) &&
                (onDate == null ||
                    ((p.ExpirationDate == null || p.ExpirationDate > onDate) &&
                    p.PostDate <= onDate)));

            switch (field.ToLower())
            {
                case "title":
                    return _posts.Where(valid).Where(p => p.Title.ToLower().Contains(searchTerm.ToLower()));
                case "content":
                    return _posts.Where(valid).Where(p => p.Content.ToLower().Contains(searchTerm.ToLower()));
                case "author":
                    return _posts.Where(valid).Where(p => p.Author.UserName.ToLower() == searchTerm.ToLower());
                case "category":
                    return _posts.Where(valid).Where(p => p.Category.Name.ToLower() == searchTerm.ToLower());
                case "tags":
                    return _posts.Where(valid).Where(p => p.Tags.Any(t => t.Name == searchTerm));
                case "approved":
                    return _posts.Where(p => p.Approved == (searchTerm != "F"));
                default:
                    //TODO: Proper error handling
                    return null;
            }
        }
    }
}
