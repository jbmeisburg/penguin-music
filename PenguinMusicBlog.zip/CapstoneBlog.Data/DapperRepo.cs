﻿//using CapstoneBlog.Models;
//using System;
//using System.Collections.Generic;
//using System.Configuration;
//using Dapper;
//using System.Data;
//using System.Data.SqlClient;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace CapstoneBlog.Data
//{
//    public class DapperRepo : IPostRepo
//    {
//        public void AddPost(Post post)
//        {
//            using (var cn = new SqlConnection())
//            {
//                cn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

//                var parameters = new DynamicParameters();

//                parameters.Add("@PostID", dbType: DbType.Int32, direction: ParameterDirection.Output);
//                parameters.Add("@PostTitle", post.Title);
//                parameters.Add("@PostContent", post.Content);

//                cn.Execute("CreateBlogPost", parameters, commandType: CommandType.StoredProcedure);

//                post.Id = parameters.Get<int>("@PostID");
//            }
//        }

//        public void DeletePost(int id)
//        {
//            using (var cn = new SqlConnection())
//            {
//                cn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;
                
//                var parameters = new DynamicParameters();
//                parameters.Add("@PostID", id);

//                cn.Execute("DeleteBlogPost", parameters, commandType: CommandType.StoredProcedure);
//            }
//        }

//        public IEnumerable<string> GetAllCategories()
//        {
//            using (var cn = new SqlConnection())
//            {
//                cn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

//                return cn.Query<String>("GetAllCategories", commandType: CommandType.StoredProcedure);
//            }
//        }

//        public IEnumerable<Post> GetAllPosts(bool approvedOnly = true, DateTime? onDate = null)
//        {
//            using (var cn = new SqlConnection())
//            {
//                cn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

//                return cn.Query<Post>("GetAllPosts", commandType: CommandType.StoredProcedure);
//            }
//        }

//        public IEnumerable<string> GetAllTags()
//        {
//            using (var cn = new SqlConnection())
//            {
//                cn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

//                return cn.Query<String>("GetAllTags", commandType: CommandType.StoredProcedure);
//            }
//        }

//        public Post GetPost(int id)
//        {
//            using (var cn = new SqlConnection())
//            {
//                cn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

//                var parameters = new DynamicParameters();
//                parameters.Add("@PostID", id);

//                return cn.Query<Post>("GetPostById", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
//            }
//        }

//        public void LoadDemo()
//        {
//            throw new NotImplementedException();
//        }

//        public IEnumerable<Post> SearchPosts(string field, string searchTerm, bool approvedOnly = true, DateTime? onDate = null)
//        {
//            switch (field.ToLower())
//            {
//                case "title":
//                    using (var cn = new SqlConnection())
//                    {
//                        cn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

//                        var parameters = new DynamicParameters();
//                        parameters.Add("@PostTitle", searchTerm);

//                        return cn.Query<Post>("SearchPostsByTitle", parameters, commandType: CommandType.StoredProcedure);
//                    };
//                case "content":
//                    using (var cn = new SqlConnection())
//                    {
//                        cn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

//                        var parameters = new DynamicParameters();
//                        parameters.Add("@PostContent", searchTerm);

//                        return cn.Query<Post>("SearchPostsByContent", parameters, commandType: CommandType.StoredProcedure);
//                    };
//                case "author":
//                    using (var cn = new SqlConnection())
//                    {
//                        cn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

//                        var parameters = new DynamicParameters();
//                        parameters.Add("@UserName", searchTerm);

//                        return cn.Query<Post>("SearchPostsByUser", parameters, commandType: CommandType.StoredProcedure);
//                    };
//                case "category":
//                    using (var cn = new SqlConnection())
//                    {
//                        cn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

//                        var parameters = new DynamicParameters();
//                        parameters.Add("@PostCategory", searchTerm);

//                        return cn.Query<Post>("SearchPostsByCategory", parameters, commandType: CommandType.StoredProcedure);
//                    };
//                case "tag":
//                    using (var cn = new SqlConnection())
//                    {
//                        cn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogSite"].ConnectionString;

//                        var parameters = new DynamicParameters();
//                        parameters.Add("@PostTag", searchTerm);

//                        return cn.Query<Post>("SearchPostsByTag", parameters, commandType: CommandType.StoredProcedure);
//                    };
//                default:
//                    return null;
//            }
//        }

//        public void UpdatePost(Post post)
//        {
//            using (var cn = new SqlConnection())
//            {
//                cn.ConnectionString = ConfigurationManager.ConnectionStrings["CPBlogsite"].ConnectionString;

//                var parameters = new DynamicParameters();
//                parameters.Add("@PostTitle", post.Title);
//                parameters.Add("@PostContent", post.Content);
//                parameters.Add("@PostCategory", post.Category);
//            }
//        }

//        int IPostRepo.AddPost(Post post)
//        {
//            throw new NotImplementedException();
//        }
//    }
//}
