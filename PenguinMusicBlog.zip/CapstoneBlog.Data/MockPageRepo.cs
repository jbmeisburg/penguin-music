﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapstoneBlog.Models;

namespace CapstoneBlog.Data
{
    public class MockPageRepo : IPageRepo
    {
        List<Page> _pages = new List<Page>();

        public void LoadDemo()
        {
            _pages = new List<Page>();
            AddPage(new Page()
            {
                Id = 1,
                Name = "Page One",
                HTML = "This is content."
            });
            AddPage(new Page()
            {
                Id = 2,
                Name = "Page Two",
                HTML = "This is also content."
            });
        }

        public int AddPage(Page page)
        {
            Page last = _pages.LastOrDefault();
            if (last == null)
                page.Id = 1;
            else
                page.Id = last.Id + 1;
            _pages.Add(page);
            return page.Id;
        }

        public void DeletePage(int id)
        {
            _pages.RemoveAll(p => p.Id == id);
        }

        public IEnumerable<Page> GetAllPages()
        {
            return _pages;
        }

        public Page GetPage(int id)
        {
            return _pages.FirstOrDefault(p => p.Id == id);
        }

        public void UpdatePage(Page page)
        {
            if (_pages.RemoveAll(p => p.Id == page.Id) >= 1)
                _pages.Add(page);
        }
    }
}
