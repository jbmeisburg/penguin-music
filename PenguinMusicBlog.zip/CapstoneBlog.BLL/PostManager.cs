﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CapstoneBlog.Data;
using CapstoneBlog.Models;

namespace CapstoneBlog.BLL
{
    public class PostManager
    {
        static IPostRepo _repo;

        public PostManager(IPostRepo repo) {
            _repo = repo;
        }

        public void LoadDemo()
        {
            _repo.LoadDemo();
        }

        public int AddPost(Post post)
        {
            //TODO: Logic for approved/not approved based on author role
            return _repo.AddPost(post);
        }

        public void DeletePost(int id)
        {
            _repo.DeletePost(id);
        }

        public void UpdatePost(Post post)
        {
            _repo.UpdatePost(post);
        }

        public Post GetPost(int id)
        {
            return _repo.GetPost(id);
        }

        public IEnumerable<Post> GetAllPosts(bool approvedOnly = true, DateTime? onDate = null)
        {
            return _repo.GetAllPosts(approvedOnly, onDate);
        }

        public IEnumerable<String> GetAllCategories()
        {
            return _repo.GetAllCategories();
        }

        public IEnumerable<String> GetAllTags()
        {
            return _repo.GetAllTags();
        }

        public IEnumerable<Post> SearchPosts(string field, string searchTerm, bool approvedOnly = true, DateTime? onDate = null)
        {
            return _repo.SearchPosts(field, searchTerm, approvedOnly, onDate);
        }
    }
}
