﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CapstoneBlog.Data;
using CapstoneBlog.Models;

namespace CapstoneBlog.BLL
{
    public class PageManager
    {
        IPageRepo _repo;

        public PageManager(IPageRepo repo)
        {
            _repo = repo;
        }

        public void LoadDemo()
        {
            _repo.LoadDemo();
        }

        public int AddPage(Page page)
        {
            return _repo.AddPage(page);
        }

        public void DeletePage(int id)
        {
            _repo.DeletePage(id);
        }

        public void UpdatePage(Page page)
        {
            _repo.UpdatePage(page);
        }

        public Page GetPage(int id)
        {
            return _repo.GetPage(id);
        }

        public IEnumerable<Page> GetAllPages()
        {
            return _repo.GetAllPages();
        }
    }
}
