﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CapstoneBlog.Models;

namespace CapstoneBlog.Models
{
    public interface IPageRepo
    {
        void LoadDemo();

        //CRUD
        int AddPage(Page page); //should return post ID
        void DeletePage(int id);
        void UpdatePage(Page page); //based on post ID
        Page GetPage(int id);
        IEnumerable<Page> GetAllPages();
    }
}
