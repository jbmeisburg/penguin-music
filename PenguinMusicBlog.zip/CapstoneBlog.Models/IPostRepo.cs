﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapstoneBlog.Models
{
    public interface IPostRepo
    {
        void LoadDemo();

        //CRUD
        int AddPost(Post post); //should return post ID
        void DeletePost(int id);
        void UpdatePost(Post post); //based on post ID
        Post GetPost(int id);

        //Searches
        IEnumerable<Post> GetAllPosts(bool approvedOnly = true, DateTime? onDate = null);
        IEnumerable<Post> SearchPosts(string field, string searchTerm, bool approvedOnly = true, DateTime? onDate = null);

        //Meta
        IEnumerable<String> GetAllCategories();
        IEnumerable<String> GetAllTags();
    }
}
