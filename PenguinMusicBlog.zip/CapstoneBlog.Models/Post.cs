﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace CapstoneBlog.Models
{
    public class Post
    {
        public int Id { get; set; }

        [Required (ErrorMessage = "Title is required!")]
        public string Title { get; set; }

        [Required (ErrorMessage = "You must have some content!")]
        public string Content { get; set; }

        [Required (ErrorMessage = "Approval status is unknown!")]
        public bool Approved { get; set; }

        [Required (ErrorMessage = "Post date is required!")]
        public DateTime PostDate { get; set; }

        public DateTime? ExpirationDate { get; set; }

        [Required (ErrorMessage = "Author object is required!")]
        public User Author { get; set; }

        [Required (ErrorMessage = "Category object is required!")]
        public Category Category { get; set; }

        public List<Tag> Tags { get; set; }
    }
}
