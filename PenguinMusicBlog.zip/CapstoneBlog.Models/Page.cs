﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CapstoneBlog.Models
{
    public class Page
    {
        public int Id { get; set; }

        [Required (ErrorMessage = "Page name is required!")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Page content is required!")]
        public string HTML { get; set; }
    }
}
