USE CPBlogSite;
GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'AddNewUser')
BEGIN
	DROP PROCEDURE AddNewUser
END
GO

CREATE PROCEDURE AddNewUser(
	@UserName VARCHAR(20)
)
AS
	INSERT INTO [User] (UserName)
	VALUES (@UserName)
GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'GetAllPages')
BEGIN
	DROP PROCEDURE GetAllPages
END
GO

CREATE PROCEDURE GetAllPages
AS
	SELECT PageName, PageHTML
	FROM StaticPage
GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'GetPageByID')
BEGIN
	DROP PROCEDURE GetPageByID
END
GO

CREATE PROCEDURE GetPageByID(
	@PageID INT
)
AS
	SELECT PageName, PageHTML
	FROM StaticPage
	WHERE PageID = @PageID
GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'AddPage')
BEGIN
	DROP PROCEDURE AddPage
END
GO

CREATE PROCEDURE AddPage(
	@PageName VARCHAR(20), @PageHTML VARCHAR(4000)
)
AS
	INSERT INTO StaticPage(PageName, PageHTML)
	VALUES (@PageName, @PageHTML)
GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'EditPage')
BEGIN
	DROP PROCEDURE EditPage
END
GO

CREATE PROCEDURE EditPage(
	@PageID INT, @PageName VARCHAR(20), @PageHTML VARCHAR(4000)
)
AS
	UPDATE StaticPage
	SET PageName = @PageName, PageHTML = @PageHTML
	WHERE PageID = @PageID
GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'DeletePage')
BEGIN
	DROP PROCEDURE DeletePage
END
GO

CREATE PROCEDURE DeletePage(
	@PageID INT
)
AS
	DELETE FROM StaticPage
	WHERE PageID = @PageID
GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'GetAllPosts'
)
BEGIN
	DROP PROCEDURE GetAllPosts
END
GO

CREATE PROCEDURE GetAllPosts
AS
	SELECT bp.PostID, u.UserName, PostTitle, PostDate, PostContent, CategoryName, ExpirationDate, Approval
	FROM [Blog Post] bp
	INNER JOIN [User] u
		ON u.UserID = bp.UserID
	LEFT JOIN PostCategory pc
		ON bp.PostID = pc.PostID
	LEFT JOIN Category c
		ON pc.CategoryID = c.CategoryID
	ORDER BY PostDate DESC
GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'GetPostsByPage')
BEGIN
	DROP PROCEDURE GetPostsByPage
END
GO

CREATE PROCEDURE GetPostsByPage
AS

DECLARE @PageNumber AS INT, @RowspPage AS INT
SET @PageNumber = 1
SET @RowspPage = 10

SELECT bp.PostID, u.UserName, PostTitle, PostDate, PostContent, CategoryName, ExpirationDate, Approval
	FROM [Blog Post] bp
	INNER JOIN [User] u
		ON u.UserID = bp.UserID
	LEFT JOIN PostCategory pc
		ON bp.PostID = pc.PostID
	LEFT JOIN Category c
		ON pc.CategoryID = c.CategoryID
	ORDER BY PostDate DESC

	OFFSET ((@PageNumber - 1) * @RowspPage) ROWS
	FETCH NEXT @RowspPage ROWS ONLY;

GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'GetPostById'
)
BEGIN
	DROP PROCEDURE GetPostById
END
GO

CREATE PROCEDURE GetPostById(
	@PostID INT
)
AS
	SELECT bp.PostID, u.UserName, PostTitle, PostDate, PostContent, CategoryName, Approval, ExpirationDate
	FROM [Blog Post] bp
	INNER JOIN [User] u
		ON u.UserID = bp.UserID
	LEFT JOIN PostCategory pc
		ON bp.PostID = pc.PostID
	LEFT JOIN Category c
		ON pc.CategoryID = c.CategoryID
	WHERE bp.PostID = @PostID
GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'GetAllCategories')
BEGIN
	DROP PROCEDURE GetAllCategories
END
GO

CREATE PROCEDURE GetAllCategories 
AS

	SELECT *
	FROM Category

GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'GetAllTags')
BEGIN
	DROP PROCEDURE GetAllTags 
END
GO

CREATE PROCEDURE GetAllTags
AS

	SELECT *
	FROM Tag

GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'SearchPostsByTitle')
BEGIN
	DROP PROCEDURE SearchPostsByTitle
END
GO

CREATE PROCEDURE SearchPostsByTitle(
	@PostTitle VARCHAR(50)
)
AS

SELECT bp.PostID, u.UserName, PostTitle, PostDate, PostContent, ExpirationDate, CategoryName, Approval
	FROM [Blog Post] bp
	INNER JOIN [User] u
		ON u.UserID = bp.UserID
	LEFT JOIN PostCategory pc
		ON bp.PostID = pc.PostID
	LEFT JOIN Category c
		ON pc.CategoryID = c.CategoryID
	WHERE bp.PostTitle LIKE '%' + @PostTitle + '%'

GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'SearchPostsByCategory')
BEGIN
	DROP PROCEDURE SearchPostsByCategory 
END
GO

CREATE PROCEDURE SearchPostsByCategory(
	@CategoryName VARCHAR(30)
)
AS
	SELECT bp.PostID, u.UserName, PostTitle, PostDate, PostContent, ExpirationDate, CategoryName, Approval
	FROM [Blog Post] bp
	INNER JOIN [User] u
		ON u.UserID = bp.UserID
	LEFT JOIN PostCategory pc
		ON bp.PostID = pc.PostID
	LEFT JOIN Category c
		ON pc.CategoryID = c.CategoryID
	WHERE c.CategoryName = @CategoryName
GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'SearchPostsByTag')
BEGIN
	DROP PROCEDURE SearchPostsByTag
END
GO

CREATE PROCEDURE SearchPostsByTag(
	@TagName VARCHAR(30)
)
AS
	SELECT bp.PostID, u.UserName, PostTitle, PostDate, PostContent, ExpirationDate, CategoryName, TagName, Approval
	FROM [Blog Post] bp
	INNER JOIN [User] u
		ON u.UserID = bp.UserID
	LEFT JOIN PostCategory pc
		ON bp.PostID = pc.PostID
	LEFT JOIN Category c
		ON pc.CategoryID = c.CategoryID
	LEFT JOIN PostTag pt
		ON bp.PostID = pt.PostID
	LEFT JOIN Tag t
		ON t.TagID = pt.TagID
	WHERE t.TagName = @TagName
GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'SearchPostsByUser')
BEGIN
	DROP PROCEDURE SearchPostsByUser
END
GO

CREATE PROCEDURE SearchPostsByUser(
	@UserName VARCHAR(20)
)
AS
	SELECT bp.PostID, u.UserName, PostTitle, PostDate, PostContent, ExpirationDate, CategoryName, Approval
	FROM [Blog Post] bp
	INNER JOIN [User] u
		ON u.UserID = bp.UserID
	LEFT JOIN PostCategory pc
		ON bp.PostID = pc.PostID
	LEFT JOIN Category c
		ON pc.CategoryID = c.CategoryID
	WHERE u.UserName LIKE '%' + @UserName + '%'
GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'SearchPostsByContent')
BEGIN
	DROP PROCEDURE SearchPostsByContent
END
GO

CREATE PROCEDURE SearchPostsByContent(
	@PostContent VARCHAR(4000)
)
AS
	SELECT bp.PostID, u.UserName, PostTitle, PostDate, PostContent, ExpirationDate, CategoryName, Approval
	FROM [Blog Post] bp
	INNER JOIN [User] u
		ON u.UserID = bp.UserID
	LEFT JOIN PostCategory pc
		ON bp.PostID = pc.PostID
	LEFT JOIN Category c
		ON pc.CategoryID = c.CategoryID
	WHERE bp.PostContent LIKE '%' + @PostContent + '%'
GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'SearchPostsByDate')
BEGIN
	DROP PROCEDURE SearchPostsByDate
END
GO

CREATE PROCEDURE SearchPostsByDate(
	@PostDate DATE
)
AS
	SELECT bp.PostID, u.UserName, PostTitle, PostDate, PostContent, ExpirationDate, CategoryName, Approval
	FROM [Blog Post] bp
	INNER JOIN [User] u
		ON u.UserID = bp.UserID
	LEFT JOIN PostCategory pc
		ON bp.PostID = pc.PostID
	LEFT JOIN Category c
		ON pc.CategoryID = c.CategoryID
	WHERE bp.PostDate >= @PostDate
GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'CreateTag')
BEGIN
	DROP PROCEDURE CreateTag
END
GO

CREATE PROCEDURE CreateTag(
	@TagName VARCHAR(20)
)
AS

INSERT INTO Tag(TagName)
VALUES (@TagName)

GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'CreateCategory')
BEGIN
	DROP PROCEDURE CreateCategory
END
GO

CREATE PROCEDURE CreateCategory(
	@CategoryName VARCHAR(30)
)
AS

INSERT INTO Category(CategoryName)
VALUES (@CategoryName)

GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'CreateBlogPost')
BEGIN
	DROP PROCEDURE CreateBlogPost
END
GO

CREATE PROCEDURE CreateBlogPost(
	@UserName VARCHAR(20), @PostTitle VARCHAR(50), @PostDate DATE, @PostContent VARCHAR(4000), @ExpirationDate DATE,
	@CategoryName VARCHAR(30), @Approval BIT
)
AS

INSERT INTO [Blog Post] (UserID, PostTitle, PostDate, PostContent, ExpirationDate, CategoryID, Approval)
VALUES ((SELECT (UserID) FROM [User] WHERE (UserName = @UserName)), @PostTitle, @PostDate, @PostContent, @ExpirationDate, 
		(SELECT (CategoryID) FROM Category WHERE (CategoryName = @CategoryName)),
		@Approval)

SELECT SCOPE_IDENTITY()

GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'GetTagsByPostID')
BEGIN
	DROP PROCEDURE GetTagsByPostID
END
GO

CREATE PROCEDURE GetTagsByPostID(
	@PostID INT
)
AS

SELECT TagName
FROM Tag t
INNER JOIN PostTag pt
	ON pt.TagID = t.TagID
INNER JOIN [Blog Post] bp
	ON bp.PostID = pt.PostID
WHERE bp.PostID = @PostID

GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'AddTagToPost')
BEGIN
	DROP PROCEDURE AddTagToPost
END
GO

CREATE PROCEDURE AddTagToPost(
	@PostID INT, @TagName VARCHAR(30)
)
AS

INSERT INTO PostTag
VALUES(@PostID, (SELECT TagID FROM Tag WHERE TagName = @TagName))

GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'EditPostTags')
BEGIN
	DROP PROCEDURE EditPostTags
END
GO

CREATE PROCEDURE EditPostTags(
	@PostID INT, @TagName VARCHAR(30)
)
AS

DELETE FROM PostTag
WHERE PostID = @PostID

INSERT INTO PostTag
VALUES(@PostID, (SELECT TagID FROM Tag WHERE TagName = @TagName))

GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'AddCategoryToPost')
BEGIN
	DROP PROCEDURE AddCategoryToPost
END
GO

CREATE PROCEDURE AddCategoryToPost(
	@PostID INT, @CategoryID INT
)
AS

INSERT INTO PostCategory
VALUES(@PostID, @CategoryID)

GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'EditBlogPost')
BEGIN
	DROP PROCEDURE EditBlogPost 
END
GO

CREATE PROCEDURE EditBlogPost(
	@PostID INT, @PostTitle VARCHAR(50), @Approval BIT, @PostContent VARCHAR(4000), 
	@ExpirationDate DATE, @CategoryName VARCHAR(30)
)
AS

UPDATE [Blog Post] 
SET PostTitle = @PostTitle, Approval = @Approval, PostContent = @PostContent, 
ExpirationDate = @ExpirationDate, CategoryID = (SELECT (CategoryID) FROM Category WHERE (CategoryName = @CategoryName))
WHERE PostID = @PostID

GO

IF EXISTS(
	SELECT *
	FROM INFORMATION_SCHEMA.ROUTINES
	WHERE ROUTINE_NAME = 'DeleteBlogPost')
BEGIN
	DROP PROCEDURE DeleteBlogPost 
END
GO

CREATE PROCEDURE DeleteBlogPost(
	@PostID INT
)
AS

DELETE FROM PostTag
WHERE PostID = @PostID

DELETE FROM PostCategory
WHERE PostID = @PostID

DELETE FROM [Blog Post]
WHERE PostID = @PostID

GO

/*
EXAMPLES:
EXEC AddCategoryToPost 17, 1
EXEC AddTagToPost 17, 1

EXEC EditBlogPost 12, 1, 'This is a lot of fun', '2017-04-02', 'Approved', 'Just edited my title to clear the spelling error', NULL, 2, 2

EXEC DeleteBlogPost 15

EXEC SearchPostsByCategory 'Joke'
EXEC SearchPostsByContent 'stuff'
EXEC SearchPostsByDate '2017-04-01'
EXEC SearchPostsByTag 'Instruments'
EXEC SearchPostsByTitle 'fun'
EXEC SearchPostsByUser 'john'

EXEC GetAllPosts

SELECT *
FROM PostTag
*/

EXEC GetAllTags