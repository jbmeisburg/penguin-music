USE CPBlogSite;
GO

INSERT INTO Tag(TagName)
VALUES ('Penguin Life'), ('Instruments'), ('Bands'), ('Venues'), ('Music-general'), ('Genre Culture'), ('Relationship-related'), ('Life-advice?')

INSERT INTO Category(CategoryName)
VALUES ('Life'), ('Joke'), ('Serious'), ('Morality'), ('Politics'), ('Food'), ('Music-Only'), ('Travel Much?')

INSERT INTO [User] (UserName)
VALUES ('OwnerLady'), ('JohnnyFartKnocker'), ('MuhammedDoneToldMe'), ('ErasmusBDragon'), ('TiredPeng')

INSERT INTO [Blog Post] (PostTitle, UserID, PostDate, Approval, PostContent, CategoryID)
VALUES ('Our very first blog post!?', 1, '03/28/2017', 1, 'I am a penguin lady who really loves music.  My favorite genres are Zydeco and Ska.', 1)

INSERT INTO [Blog Post] (PostTitle, UserID, PostDate, Approval, PostContent, CategoryID)
VALUES ('Gig life in the antarctic', 2, '03/28/2017', 1, 'I am a gigging penguin, just trying make a gig life for myself in the soul-crushing music scene here in the Antarctic.', 3)

INSERT INTO [Blog Post] (PostTitle, UserID, PostDate, Approval, PostContent, CategoryID)
VALUES ('My wife doesn''t like the music I do', 3, '03/28/2017', 1, 'I''m a fan of opera, she''s a fan of gothic industrial death metal.  What should I do?', 4)

INSERT INTO [Blog Post] (PostTitle, UserID, PostDate, Approval, PostContent, CategoryID)
VALUES ('Best venue for a music festival', 4, '03/28/2017', 1, 'I''m planning to start a new music festival next year.  Which venue is the most friendly to people travelling from all over the continent and several others as well?', 3)

INSERT INTO [Blog Post] (PostTitle, UserID, PostDate, Approval, PostContent, CategoryID)
VALUES ('I got tired of pacing the floor', 2, '04/28/2017', 1, 'Walked away ever since I got a new job climbing the walls.', 2)

INSERT INTO [Blog Post] (PostTitle, UserID, PostDate, Approval, PostContent, CategoryID)
VALUES ('You''re name it is unpronounceable', 3, '04/03/2017', 1, 'Distorted and inlegible...I never figured out what that was.  If I didn''t then, I know I never will.', 3)

INSERT INTO [Blog Post] (PostTitle, UserID, PostDate, Approval, PostContent, CategoryID)
VALUES ('Um', 5, '05/01/2017', 1, 'Have you guys been posting random They Might Be Giants lyrics this whole time??', 1)

INSERT INTO [Blog Post] (PostTitle, UserID, PostDate, Approval, PostContent, CategoryID)
VALUES ('Fuck you moderator guy!', 2, '05/01/2017', 0, '<title>', 5)

INSERT INTO PostTag (PostID, TagID)
VALUES (1, 1), (2, 3), (3, 7), (4, 4), (5, 8), (6, 8), (7, 1), (8, 7)

INSERT INTO PostCategory(PostID, CategoryID)
VALUES (1, 1), (2, 3), (3, 4), (4, 3), (5, 2), (6, 3), (7, 1), (8, 5)

SELECT bp.PostID, u.UserName, PostTitle, PostDate, PostContent, CategoryName, TagName
FROM [Blog Post] bp
INNER JOIN [User] u
	ON u.UserID = bp.UserID
LEFT JOIN PostCategory pc
	ON bp.PostID = pc.PostID
LEFT JOIN Category c
	ON pc.CategoryID = c.CategoryID
LEFT JOIN PostTag pt
	ON bp.PostID = pt.PostID
LEFT JOIN Tag t
	ON pt.TagID = t.TagID
GO